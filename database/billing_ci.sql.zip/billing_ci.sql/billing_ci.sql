-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2018 at 08:34 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `billing_ci`
--
CREATE DATABASE IF NOT EXISTS `billing_ci` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `billing_ci`;

-- --------------------------------------------------------

--
-- Table structure for table `combo_master`
--

CREATE TABLE IF NOT EXISTS `combo_master` (
`combo_id` int(11) NOT NULL,
  `combo_case` varchar(150) DEFAULT NULL,
  `combo_key` varchar(1500) DEFAULT NULL,
  `combo_value` varchar(1500) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `combo_master`
--

INSERT INTO `combo_master` (`combo_id`, `combo_case`, `combo_key`, `combo_value`, `seq`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(2, 'STATUS', 'ACTIVE', 'Active', 0, 'ACTIVE', 0, 3, '0000-00-00 00:00:00', '2015-10-30 15:01:16'),
(3, 'STATUS', 'DEACTIVE', 'Deactive', 1, 'Active', 0, 3, '0000-00-00 00:00:00', '2015-10-30 15:01:28'),
(6, 'MEASURE', 'kg', 'kg', 1, 'ACTIVE', 3, 0, '2015-10-21 13:36:26', '2015-10-21 13:36:26'),
(9, 'MEASURE', 'qty', 'qty', 2, 'ACTIVE', 3, 0, '2015-11-17 15:14:41', '2015-11-17 15:14:41'),
(10, 'PRODUCT_TYPE', 'product', 'Product', 1, 'ACTIVE', 3, 3, '2015-12-04 16:39:38', '2017-07-30 11:22:37'),
(11, 'PRODUCT_TYPE', 'component', 'Component', 2, 'ACTIVE', 3, 3, '2015-12-04 16:40:00', '2015-12-09 17:41:13'),
(12, 'DISCOUNT_TYPE', 'rs', 'Rs', 0, 'ACTIVE', 3, 3, '2016-01-16 07:36:34', '2016-01-16 07:51:46'),
(13, 'DISCOUNT_TYPE', '%', '%', 1, 'ACTIVE', 3, 0, '2016-01-16 07:37:11', '2016-01-16 07:37:11');

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE IF NOT EXISTS `customer_master` (
`cust_id` int(11) NOT NULL,
  `cust_first_name` varchar(100) DEFAULT NULL,
  `cust_last_name` varchar(100) DEFAULT NULL,
  `cust_company_name` varchar(200) DEFAULT NULL,
  `cust_email` varchar(150) DEFAULT NULL,
  `cust_phone` varchar(20) DEFAULT NULL,
  `cust_mobile` varchar(20) DEFAULT NULL,
  `cust_website` varchar(200) DEFAULT NULL,
  `shipping_street` text,
  `shipping_city` varchar(50) DEFAULT NULL,
  `shipping_state` varchar(50) DEFAULT NULL,
  `shipping_zipcode` varchar(10) DEFAULT NULL,
  `shipping_country` varchar(20) DEFAULT NULL,
  `billing_street` text,
  `billing_city` varchar(50) DEFAULT NULL,
  `billing_state` varchar(50) DEFAULT NULL,
  `billing_zipcode` varchar(10) DEFAULT NULL,
  `billing_country` varchar(20) DEFAULT NULL,
  `note` text,
  `status` varchar(20) DEFAULT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`cust_id`, `cust_first_name`, `cust_last_name`, `cust_company_name`, `cust_email`, `cust_phone`, `cust_mobile`, `cust_website`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zipcode`, `shipping_country`, `billing_street`, `billing_city`, `billing_state`, `billing_zipcode`, `billing_country`, `note`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(1, 'mayank', 'jethvani', 'ehealthsource', 'test@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ACTIVE', NULL, NULL, NULL, NULL),
(2, 'saurabh', 'mehta', 'ehealthsource', 'test@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ACTIVE', NULL, NULL, NULL, NULL),
(3, 'Dhruv', 'Shah', 'ehealthsource', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ACTIVE', NULL, NULL, NULL, NULL),
(4, 'Darshan', 'Shankar', 'ehealthsource', 'trapasia.snehal@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ACTIVE', NULL, NULL, NULL, NULL),
(5, 'Bhavik', 'Kakadiya', 'ehealthsource', 'bhavik.kakadiya@gmail.com', NULL, '8866771641', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ACTIVE', NULL, NULL, NULL, NULL),
(6, 'snehal', 'traspiya', NULL, '', '', '8866771643', '', '101 shiv shyam apartment', 'ahmedabad', 'gujarat', 'snehal', 'india', '101 shiv shyam apartment', 'ahmedabad', 'gujarat', '460001', 'india', NULL, 'ACTIVE', 3, NULL, '2016-01-05 16:08:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` int(10) NOT NULL DEFAULT '0',
  `template_type` varchar(255) CHARACTER SET latin1 NOT NULL,
  `subject` varchar(255) CHARACTER SET latin1 NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`template_id`, `template_type`, `subject`, `description`) VALUES
(1, 'INTERN_WELCOME_EMAIL', 'Welcome to FindYourInternship ', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n	margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n<table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n	<tr>\r\n    	<td>\r\n        	<div style="background-color:#404040;height:40px;">\r\n            	<div style="font-size:30px;margin-left:15px;margin-top:10px;">\r\n                    <span style="color:#FFF;">FindYour</span><span style="color:#199B45;">Internship</span>\r\n                </div>\r\n            </div>\r\n        </td>\r\n    </tr>\r\n    <tr>\r\n    	<td style="background-color:#D9D9D9;padding:60px 20px;" align="center">\r\n	    	\r\n            <table width="100%" cellpadding="5" cellspacing="0" border="2" style="border-collapse:collapse;border:2px solid #199B45;">\r\n            	\r\n                <tr valign="top">\r\n                	<td style="border:2px solid #199B45;" colspan="2">\r\n                   	  <p>Hi {INTERN_NAME},</p>\r\n                   	  <p>Welcome  to FindYourInternship. Your account has been created.</p>\r\n						<p><strong>Find Your Internship with leading professionals in academia  and industry and advance yourself professionally.</strong></p>\r\n                       <p>&nbsp;</p>\r\n                       <p>Here’s what you need to do:</p>\r\n                    </td>\r\n                    \r\n                    <td rowspan="3" valign="top" align="center" style="border:2px solid #199B45;" width="30%">\r\n                    	<div style="width:250px;" align="center">\r\n                        	<table width="100%" cellpadding="0" cellspacing="0" border="1">\r\n                            	<tr>\r\n                                	<td bgcolor="#404040" style="border:1px solid #7f7f7f;">\r\n                                    	<p style="color:#FFF;"><strong>Sign in to FindYourInternship and succeed professionally.</strong></p>\r\n                                        <p>&nbsp;</p>\r\n									</td>\r\n                                </tr>\r\n                                <tr>\r\n                                	<td bgcolor="#199B45" align="center" valign="middle" style="padding:10px 0px;border:1px solid #7f7f7f">\r\n                                    	<a href="{FYI_WEB_URL}" style="font-size:20px;color:#000;text-decoration:none;">\r\n                                        	<strong>Get Started</strong>\r\n                                        </a>\r\n                                    </td>\r\n                                </tr>\r\n                            </table>\r\n                        </div>\r\n                    </td>\r\n                    \r\n                </tr>\r\n                \r\n                <tr>\r\n                	<td style="border:2px solid #199B45;width:30px;">\r\n                    	<img src="{FYI_EMAIL_IMAGE_PATH}" border="0" />\r\n                    </td>\r\n                	<td style="border:2px solid #199B45;">\r\n                    	<div style="font-size:18px;color:#199B45;"><strong>Build Your Profile.</strong></div>\r\n                        <span>Takes just 60 seconds.</span>\r\n                    </td>\r\n                </tr>\r\n                \r\n                <tr>\r\n                	<td style="border:2px solid #199B45;width:30px;">\r\n                    	<img src="{FYI_EMAIL_IMAGE_PATH}" border="0" />\r\n                    </td>\r\n                	<td style="border:2px solid #199B45;">\r\n                    	<div style="font-size:18px;color:#199B45;"><strong>Find and Apply For an Internship</strong></div>\r\n                        <span>Gain valuable experience with some of the leading industry and academic professionals quickly and easily.</span>\r\n                    </td>\r\n                </tr>\r\n                \r\n                <tr>\r\n                	<td style="border:2px solid #199B45;" colspan="2">\r\n                    	<p>	Thanks, <br />\r\n							The FindYourInternship Team.\r\n						</p>\r\n                    </td>\r\n                   	<td style="border:2px solid #199B45;">\r\n                      <p>If  you like our site, Please <a href="{FYI_REFER_URL}" style="color:#199B45;">Refer us to a friend  by clicking here</a>.</p>\r\n                    </td>\r\n                </tr>\r\n            </table>\r\n		</td>\r\n    </tr>\r\n</table>\r\n</div>'),
(2, 'MENTOR_WELCOME_EMAIL', 'Welcome to FindYourInternship ', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n	margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n<table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n	<tr>\r\n    	<td>\r\n        	<div style="background-color:#404040;height:40px;">\r\n            	<div style="font-size:30px;margin-left:15px;margin-top:10px;">\r\n                    <span style="color:#FFF;">FindYour</span><span style="color:#199B45;">Internship</span>\r\n                </div>\r\n            </div>\r\n        </td>\r\n    </tr>\r\n    <tr>\r\n    	<td style="background-color:#D9D9D9;padding:60px 20px;" align="center">\r\n	    	\r\n            <table width="100%" cellpadding="5" cellspacing="0" border="2" style="border-collapse:collapse;border:2px solid #199B45;">\r\n            	\r\n                <tr valign="top">\r\n                	<td style="border:2px solid #199B45;" colspan="2" width="30%">>\r\n                   	  	<p>Hi {MENTOR_NAME},</p>\r\n                   	  	<p>Welcome  to FindYourInternship. Your account has been created.</p>\r\n						<p>FindYourInternship.com  helps you find incredibly talented interns </p>\r\n						<p>\r\n                        	<ul>\r\n                            	<li><strong>You can sort out the best interns</strong> within minutes with our pre-set and your customized criteria</li>\r\n 								<li>No more e-mail spam from students</li>\r\n								<li>Its 100% FREE.</li>\r\n                            </ul>\r\n                        </p>\r\n                       	<p>Here’s what you need to do:</p>\r\n                    </td>\r\n                    \r\n                    <td rowspan="3" valign="top" align="center" style="border:2px solid #199B45;">\r\n                    	<div style="width:250px;">\r\n                        	<table width="100%" cellpadding="0" cellspacing="0" border="1">\r\n                            	<tr>\r\n                                	<td bgcolor="#404040" style="border:1px solid #7f7f7f;">\r\n                                    	<p style="color:#FFF;"><strong>Sign in to FindYourInternship and succeed professionally.</strong></p>\r\n                                        <p>&nbsp;</p>\r\n									</td>\r\n                                </tr>\r\n                                <tr>\r\n                                	<td bgcolor="#199B45" align="center" valign="middle" style="padding:10px 0px;border:1px solid #7f7f7f">\r\n                                    	<a href="{FYI_WEB_URL}" style="font-size:20px;color:#000;text-decoration:none;">\r\n                                        	<strong>Get Started</strong>\r\n                                        </a>\r\n                                    </td>\r\n                                </tr>\r\n                            </table>\r\n                        </div>\r\n                    </td>\r\n                    \r\n                </tr>\r\n                \r\n                <tr>\r\n                	<td style="border:2px solid #199B45;width:30px;">\r\n                    	<img src="{FYI_EMAIL_IMAGE_PATH}" border="0" />\r\n                    </td>\r\n                	<td style="border:2px solid #199B45;">\r\n                    	<div style="font-size:18px;color:#199B45;"><strong>Build Your Profile.</strong></div>\r\n                        <span>Takes just 60 seconds.</span>\r\n                    </td>\r\n                </tr>\r\n                \r\n                <tr>\r\n                	<td style="border:2px solid #199B45;width:30px;">\r\n                    	<img src="{FYI_EMAIL_IMAGE_PATH}" border="0" />\r\n                    </td>\r\n                	<td style="border:2px solid #199B45;">\r\n                    	<div style="font-size:18px;color:#199B45;"><strong>Find and Apply For an Internship</strong></div>\r\n                    	<p>Easy  as 1,2,3. Sort interns based on pre-set criteria such as GPA, university  rankings and location or customize your own sorting criteria. No more Email  spam and it&rsquo;s 100% free.</p></td>\r\n                </tr>\r\n                \r\n                <tr>\r\n                	<td style="border:2px solid #199B45;" colspan="2">\r\n                    	<p>	Thanks, <br />\r\n							The FindYourInternship Team.\r\n						</p>\r\n                    </td>\r\n                   	<td style="border:2px solid #199B45;">\r\n                      <p>If  you like our site, Please <a href="{FYI_REFER_URL}" style="color:#199B45;">Refer us to a friend  by clicking here</a>.</p>\r\n                    </td>\r\n                </tr>\r\n            </table>\r\n		</td>\r\n    </tr>\r\n</table>\r\n</div>'),
(3, 'REFER_EMAIL', 'Welcome to FindYourInternship ', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n	margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n    <table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n        <tr>\r\n            <td><div style="background-color:#404040;height:40px;">\r\n                    <div style="font-size:30px;margin-left:15px;margin-top:10px;"> <span style="color:#FFF;">FindYour</span><span style="color:#199B45;">Internship</span> </div>\r\n                </div></td>\r\n        </tr>\r\n        <tr>\r\n            <td style="background-color:#D9D9D9;padding:60px 20px;" align="center"><table width="100%" cellpadding="5" cellspacing="0" border="2" style="border-collapse:collapse;border:2px solid #199B45;">\r\n                    <tr valign="top">\r\n                        <td style="border:2px solid #199B45;" colspan="2">\r\n                        	<p>Hi {REFEREE_NAME},</p>\r\n                            <p>{INTERN_NAME} has  suggested you as his referee. </p>\r\n                            <p>Please sign up or sign in on <u>FindYourInternship.com</u> and  rate the intern in less than 60 seconds.                            </p>\r\n                            <p>Please Click below link to rate the intern:</p>\r\n                            <p>{REFER_URL}</p>\r\n                            <p>FindYourInternship.com  helps you find incredibly talented interns &ndash;\r\n                            <ul>\r\n                                <li><strong>You can sort out the best interns</strong> within minutes with our pre-set and your customized criteria</li>\r\n                                <li>No more e-mail spam from students</li>\r\n                                <li>Its 100% FREE.</li>\r\n                            </ul>\r\n                        </td>\r\n                        <td rowspan="3" valign="top" align="center" style="border:2px solid #199B45;" width="30%"><div style="width:250px;">\r\n                                <table width="100%" cellpadding="0" cellspacing="0" border="1">\r\n                                    <tr>\r\n                                        <td bgcolor="#404040" style="border:1px solid #7f7f7f;"><p style="color:#FFF;"><strong>Sign in to FindYourInternship and succeed professionally.</strong></p>\r\n                                            <p>&nbsp;</p></td>\r\n                                    </tr>\r\n                                    <tr>\r\n                                        <td bgcolor="#199B45" align="center" valign="middle" style="padding:10px 0px;border:1px solid #7f7f7f"><a href="{FYI_WEB_URL}" style="font-size:20px;color:#000;text-decoration:none;"> <strong>Get Started</strong> </a></td>\r\n                                    </tr>\r\n                                </table>\r\n                            </div></td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td style="border:2px solid #199B45;width:30px;"><img src="{FYI_EMAIL_IMAGE_PATH}" border="0" /></td>\r\n                        <td style="border:2px solid #199B45;"><div style="font-size:18px;color:#199B45;"><strong>Find The Best Interns-Your Way.</strong></div>\r\n                            <span>Easy as 1,2,3. Sort interns based on pre-set criteria such as GPA, university rankings and location or Customize your own sorting criteria. No more Email spam and it’s 100% free.</span></td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</div>\r\n'),
(4, 'FORGOT_PASSWORD_EMAIL', 'Reset Password (Order Tracking System)', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n	margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n    <table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n        <tr>\r\n            <td><div style="background-color:#404040;height:40px;">\r\n                    <div style="font-size:30px;margin-left:15px;margin-top:10px;"> <span style="color:#FFF;">Order</span><span style="color:#199B45;"> Tracking</span><span style="color:#478fca;"> System</span> </div>\r\n                </div></td>\r\n        </tr>\r\n        <tr>\r\n            <td style="background-color:#E8E8E8;padding:35px;" align="center">\r\n            	<table width="100%" cellpadding="5" cellspacing="0" border="1" style="border-collapse:collapse;border:1px solid #199B45;">\r\n                    <tr valign="top">\r\n                        <td style="border:0px solid #199B45;" colspan="2"><p>Hi {USER_NAME},</p>\r\n                            <p>&nbsp;</p>\r\n                            <p> Can''t remember your password, huh?  It happens to the best of us. </p>\r\n                            <p>&nbsp;</p>\r\n                            <p> Please click on the link below or copy and paste the URL into your browser: <br /></p>\r\n							<p>{RESET_PASSWORD_URL}</p>\r\n							<p>&nbsp;</p>\r\n							<p>This will reset your password.  You can then login and change it to something you''ll remember. </p>\r\n							<p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                    </tr>\r\n					<tr>\r\n                        <td style="border:0px solid #199B45;" colspan="2">\r\n                            <p>	Thanks, <br />\r\n                                Order Tracking System.\r\n                            </p>\r\n                        </td>\r\n                    </tr>\r\n                </table></td>\r\n        </tr>\r\n    </table>\r\n</div>\r\n'),
(5, 'WELCOME_EMAIL', 'Welcome to Ontario Soccer Association', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n	margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n    <table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n        <tr>\r\n            <td><div style="background-color:#404040;height:40px;">\r\n                    <div style="font-size:30px;margin-left:15px;margin-top:10px;"> <span style="color:#FFF;">Ontario</span><span style="color:#199B45;"> Soccer</span><span style="color:#478fca;"> Association</span> </div>\r\n                </div></td>\r\n        </tr>\r\n        <tr>\r\n            <td style="background-color:#E8E8E8;padding:35px;" align="center">\r\n            	<table width="100%" cellpadding="5" cellspacing="0" border="1" style="border-collapse:collapse;border:1px solid #199B45;">\r\n                    <tr valign="top">\r\n                        <td style="border:0px solid #199B45;" colspan="2"><p>Hi {USER_NAME},</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>Welcome  to Ontario Soccer Association. Your account has been created.</p>\r\n							<p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                         </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td style="border:0px solid #199B45;" colspan="2">\r\n                            <p>	Thanks, <br />\r\n                                Ontario Soccer Association.\r\n                            </p>\r\n                        </td>\r\n                    </tr>\r\n                </table></td>\r\n        </tr>\r\n    </table>\r\n</div>'),
(6, 'SUBMIT_FORM_EMAIL', 'Submit {FORM_TYPE}', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n	margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n    <table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n        <tr>\r\n            <td><div style="background-color:#404040;height:40px;">\r\n                    <div style="font-size:30px;margin-left:15px;margin-top:10px;"> <span style="color:#FFF;">Ontario</span><span style="color:#199B45;"> Soccer</span><span style="color:#478fca;"> Association</span> </div>\r\n                </div></td>\r\n        </tr>\r\n        <tr>\r\n            <td style="background-color:#E8E8E8;padding:35px;" align="center">\r\n            	<table width="100%" cellpadding="5" cellspacing="0" border="1" style="border-collapse:collapse;border:1px solid #199B45;">\r\n                    <tr valign="top">\r\n                        <td style="border:0px solid #199B45;" colspan="2"><p>Hi {USER_NAME},</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>Your {FORM_TYPE} has been submitted Successfully.</p>\r\n							<p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                        </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td style="border:0px solid #199B45;" colspan="2">\r\n                            <p>	Thanks, <br />\r\n                                Ontario Soccer Association.\r\n                            </p>\r\n                        </td>\r\n                    </tr>\r\n                </table></td>\r\n        </tr>\r\n    </table>\r\n</div>'),
(7, 'INVOICE_EMAIL', 'OTSINV Invoice', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<style>\r\np {\r\n margin:5px;\r\n}\r\n</style>\r\n<div style="font-family:Calibri;">\r\n    <table width="100%" cellpadding="0" cellspacing="0" border="0">\r\n        <tr>\r\n            <td><div style="background-color:#404040;height:40px;">\r\n                    <div style="font-size:30px;margin-left:15px;margin-top:10px;"> <span style="color:#FFF;">Order</span><span style="color:#199B45;"> Management</span><span style="color:#478fca;"> System</span> </div>\r\n                </div></td>\r\n        </tr>\r\n        <tr>\r\n            <td style="background-color:#E8E8E8;padding:35px;" align="center">\r\n             <table width="100%" cellpadding="5" cellspacing="0" border="1" style="border-collapse:collapse;border:1px solid #199B45;">\r\n                    <tr valign="top">\r\n                        <td style="border:0px solid #199B45;" colspan="2"><p>Hi {CUSTOMER_NAME},</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>Your Invoice has been created for order <b>{ORDER_NO}</b> on {ORDER_DATE}</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>Please Find Attached Invoice File.</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                            <p>&nbsp;</p>\r\n                        </td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td style="border:0px solid #199B45;" colspan="2">\r\n                            <p> Thanks, <br />\r\n                            Order Management System.\r\n                            </p>\r\n                        </td>\r\n                    </tr>\r\n                </table></td>\r\n        </tr>\r\n    </table>\r\n</div>');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
`invoice_id` bigint(20) NOT NULL,
  `invoice_no` varchar(30) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `invoice_date` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `invoice_no`, `order_id`, `invoice_date`, `created_by`) VALUES
(1, 'INV-0000', 1, '2016-02-10 02:19:41', 3),
(2, 'INV-0002', 2, '2016-02-12 03:28:26', 3);

-- --------------------------------------------------------

--
-- Table structure for table `item_color_master`
--

CREATE TABLE IF NOT EXISTS `item_color_master` (
`item_color_id` int(11) NOT NULL,
  `item_color_name` varchar(150) DEFAULT NULL,
  `item_color_code` varchar(150) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `item_color_master`
--

INSERT INTO `item_color_master` (`item_color_id`, `item_color_name`, `item_color_code`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(3, 'red', 'red', 'ACTIVE', 3, NULL, '2017-08-09 19:56:02', '2017-08-09 19:56:02'),
(4, 'blue', 'blue', 'ACTIVE', 3, NULL, '2017-08-09 19:58:07', '2017-08-09 19:58:07');

-- --------------------------------------------------------

--
-- Table structure for table `item_thickness_master`
--

CREATE TABLE IF NOT EXISTS `item_thickness_master` (
`item_thk_id` int(11) NOT NULL,
  `item_thk_name` varchar(150) DEFAULT NULL,
  `item_thk_code` varchar(150) DEFAULT NULL,
  `item_thickness` int(11) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `item_thickness_master`
--

INSERT INTO `item_thickness_master` (`item_thk_id`, `item_thk_name`, `item_thk_code`, `item_thickness`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(3, '6 MM', '6 MM', 6, 'ACTIVE', 3, NULL, '2017-08-09 20:37:54', '2017-08-09 20:37:54');

-- --------------------------------------------------------

--
-- Table structure for table `map_usertype_module`
--

CREATE TABLE IF NOT EXISTS `map_usertype_module` (
`id` int(11) NOT NULL,
  `utype_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `map_usertype_module`
--

INSERT INTO `map_usertype_module` (`id`, `utype_id`, `module_id`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(2, 1, 5, 3, 0, '2015-10-16 14:41:28', '2015-10-16 14:41:28'),
(3, 2, 5, 3, 0, '2015-10-16 14:42:22', '2015-10-16 14:42:22'),
(4, 2, 4, 3, 0, '2015-10-16 14:49:23', '2015-10-16 14:49:23'),
(5, 4, 4, 3, 0, '2015-10-16 15:13:56', '2015-10-16 15:13:56'),
(6, 1, 6, 3, 0, '2015-10-19 18:42:11', '2015-10-19 18:42:11'),
(7, 1, 10, 3, 0, '2015-10-19 18:42:22', '2015-10-19 18:42:22'),
(8, 1, 21, 3, 0, '2015-10-20 17:27:44', '2015-10-20 17:27:44'),
(9, 1, 7, 3, 0, '2015-10-20 17:45:58', '2015-10-20 17:45:58'),
(10, 1, 8, 3, 0, '2015-10-21 12:05:42', '2015-10-21 12:05:42'),
(11, 1, 9, 3, 0, '2015-10-21 12:05:47', '2015-10-21 12:05:47'),
(12, 1, 11, 3, 0, '2015-10-21 12:05:55', '2015-10-21 12:05:55'),
(13, 1, 12, 3, 0, '2015-10-21 12:05:59', '2015-10-21 12:05:59'),
(14, 1, 13, 3, 0, '2015-10-21 12:06:03', '2015-10-21 12:06:03'),
(15, 1, 14, 3, 0, '2015-10-21 12:06:22', '2015-10-21 12:06:22'),
(16, 1, 15, 3, 0, '2015-10-21 12:06:31', '2015-10-21 12:06:31'),
(17, 1, 16, 3, 0, '2015-10-21 12:06:37', '2015-10-21 12:06:37'),
(18, 1, 17, 3, 0, '2015-10-21 12:06:56', '2015-10-21 12:06:56'),
(19, 1, 18, 3, 0, '2015-10-21 12:07:05', '2015-10-21 12:07:05'),
(20, 1, 19, 3, 0, '2015-10-21 12:07:12', '2015-10-21 12:07:12'),
(21, 1, 20, 3, 0, '2015-10-21 12:07:22', '2015-10-21 12:07:22'),
(22, 1, 22, 3, 0, '2015-10-21 12:07:37', '2015-10-21 12:07:37'),
(23, 1, 23, 3, 0, '2015-10-21 14:21:26', '2015-10-21 14:21:26'),
(29, 1, 25, 3, 0, '2015-11-26 14:21:07', '2015-11-26 14:21:07'),
(30, 1, 26, 3, 0, '2015-11-26 14:21:08', '2015-11-26 14:21:08'),
(31, 1, 27, 3, 0, '2015-11-26 14:21:09', '2015-11-26 14:21:09'),
(32, 2, 27, 3, 0, '2015-11-26 17:52:58', '2015-11-26 17:52:58'),
(34, 1, 24, 3, 0, '2015-12-02 16:07:41', '2015-12-02 16:07:41'),
(36, 1, 28, 3, 0, '2016-01-23 16:59:50', '2016-01-23 16:59:50'),
(37, 1, 29, 3, 0, '2017-07-30 12:15:13', '2017-07-30 12:15:13'),
(38, 1, 30, 3, 0, '2017-08-09 19:59:43', '2017-08-09 19:59:43'),
(39, 1, 31, 3, 0, '2017-08-09 20:39:14', '2017-08-09 20:39:14'),
(40, 6, 6, 3, 0, '2017-08-29 20:58:47', '2017-08-29 20:58:47'),
(41, 6, 28, 3, 0, '2017-08-29 20:58:57', '2017-08-29 20:58:57'),
(42, 6, 12, 3, 0, '2017-08-29 20:59:37', '2017-08-29 20:59:37');

-- --------------------------------------------------------

--
-- Table structure for table `map_user_status`
--

CREATE TABLE IF NOT EXISTS `map_user_status` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `map_user_status`
--

INSERT INTO `map_user_status` (`id`, `user_id`, `status_id`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(3, 6, 6, 3, 0, '2016-01-08 17:16:23', '2016-01-08 17:16:23'),
(4, 4, 8, 3, 0, '2016-01-08 17:16:30', '2016-01-08 17:16:30'),
(5, 3, 7, 3, 0, '2016-01-18 10:00:48', '2016-01-18 10:00:48'),
(6, 3, 6, 3, 0, '2016-01-18 18:49:56', '2016-01-18 18:49:56'),
(7, 3, 9, 3, 0, '2016-01-18 18:49:57', '2016-01-18 18:49:57'),
(8, 3, 8, 3, 0, '2016-01-18 18:49:57', '2016-01-18 18:49:57'),
(9, 3, 10, 3, 0, '2016-01-18 18:49:59', '2016-01-18 18:49:59');

-- --------------------------------------------------------

--
-- Table structure for table `module_master`
--

CREATE TABLE IF NOT EXISTS `module_master` (
`module_id` int(11) NOT NULL,
  `panel_id` int(11) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `module_url` varchar(200) NOT NULL,
  `seq` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL,
  `is_right_button` tinyint(1) NOT NULL DEFAULT '0',
  `right_button_link` varchar(200) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `module_master`
--

INSERT INTO `module_master` (`module_id`, `panel_id`, `module_name`, `module_url`, `seq`, `status`, `is_right_button`, `right_button_link`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(6, 5, 'Add User', 'index.php?c=user', '1', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:03:03', '2015-10-19 17:03:03'),
(11, 7, 'Manage Status', 'index.php?c=status', '1', 'ACTIVE', 0, '', 3, 3, '2015-10-19 17:06:56', '2016-01-18 08:54:20'),
(12, 8, 'Manage Vendor', 'index.php?c=vendor', '1', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:07:25', '2015-10-19 17:07:25'),
(13, 9, 'Manage Product', 'index.php?c=product', '1', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:08:10', '2015-10-19 17:08:10'),
(14, 9, 'Product Category', 'index.php?c=product&m=Category_list', '2', 'ACTIVE', 0, '', 3, 3, '2015-10-19 17:08:41', '2015-10-21 14:05:19'),
(19, 12, 'Panel List', 'index.php?c=setting&m=panel_list', '1', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:11:22', '2015-10-19 17:11:22'),
(20, 12, 'Module List', 'index.php?c=setting&m=module_list', '2', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:12:08', '2015-10-19 17:12:08'),
(21, 12, 'Assign Module to Utype', 'index.php?c=setting&m=frmAssignModule', '3', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:12:59', '2015-10-19 17:12:59'),
(22, 12, 'Manage Combo', 'index.php?c=setting&m=comboList', '4', 'ACTIVE', 0, '', 3, 0, '2015-10-19 17:13:28', '2015-10-19 17:13:28'),
(23, 12, 'Manage Setting', 'index.php?c=setting&m=setting_list', '5', 'DEACTIVE', 0, '', 3, 3, '2015-10-21 14:21:04', '2017-07-30 12:01:52'),
(28, 14, 'View Orders', 'index.php?c=order', '2', 'ACTIVE', 1, 'index.php?c=order&m=createOrder', 3, 3, '2016-01-08 17:29:22', '2017-08-29 21:00:16'),
(29, 5, 'Add user type', 'index.php?c=user&m=userTypesList', '2', 'ACTIVE', 0, '', 3, 0, '2017-07-30 12:09:41', '2017-07-30 12:09:41'),
(30, 9, 'Manage Item Color', 'index.php?c=itemcolor', '3', 'ACTIVE', 0, '', 3, 0, '2017-08-09 19:59:35', '2017-08-09 19:59:35'),
(31, 9, 'Manage Item Thickness', 'index.php?c=itemthickness', '4', 'ACTIVE', 0, '', 3, 3, '2017-08-09 20:39:06', '2017-08-09 20:39:49');

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE IF NOT EXISTS `order_master` (
`order_id` int(11) NOT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sub_total_amount` double DEFAULT NULL,
  `total_cgst` float DEFAULT NULL,
  `total_sgst` float DEFAULT NULL,
  `total_gst` float DEFAULT NULL,
  `final_total_amount` double DEFAULT NULL,
  `order_payment_type` varchar(150) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `order_due_date` date DEFAULT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `order_note` text,
  `is_complete` int(1) DEFAULT '0',
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `order_master`
--

INSERT INTO `order_master` (`order_id`, `order_no`, `customer_id`, `sub_total_amount`, `total_cgst`, `total_sgst`, `total_gst`, `final_total_amount`, `order_payment_type`, `order_date`, `order_due_date`, `order_status`, `order_note`, `is_complete`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(1, 'CO-0000', 1, 10853, 651.18, 651.18, 1302.36, 12155.36, NULL, '2017-08-26', '2017-08-31', 'pending', 'this is testing1', 0, 3, 3, '2017-08-26 13:48:54', '2017-08-27 08:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `order_product_detail`
--

CREATE TABLE IF NOT EXISTS `order_product_detail` (
`opd_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `prod_name` varchar(255) DEFAULT NULL,
  `prod_qty` float DEFAULT NULL,
  `price_per_qty` float DEFAULT NULL,
  `prod_total_amount` double DEFAULT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `order_product_detail`
--

INSERT INTO `order_product_detail` (`opd_id`, `order_id`, `prod_name`, `prod_qty`, `price_per_qty`, `prod_total_amount`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(7, 1, 'modi look3', 142.4, 54, 7668, NULL, 3, NULL, '2017-08-27 08:27:46'),
(8, 1, 'modi look2', 130, 24.5, 3185, NULL, 3, NULL, '2017-08-27 08:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `order_product_status`
--

CREATE TABLE IF NOT EXISTS `order_product_status` (
`ops_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `status_note` text,
  `insert_by` int(11) DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  `insert_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `panel_master`
--

CREATE TABLE IF NOT EXISTS `panel_master` (
`panel_id` int(11) NOT NULL,
  `panel_name` varchar(200) NOT NULL,
  `seq` varchar(50) NOT NULL,
  `img_url` varchar(500) NOT NULL,
  `status` varchar(50) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `panel_master`
--

INSERT INTO `panel_master` (`panel_id`, `panel_name`, `seq`, `img_url`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(5, 'Manage User', '1', '<i class=''icon-edit''></i>', 'ACTIVE', 3, 3, '2015-10-19 16:58:37', '2017-07-30 11:40:15'),
(7, 'Status', '3', '<i class=''icon-edit''></i>', 'ACTIVE', 3, 3, '2015-10-19 16:59:06', '2016-01-18 08:52:18'),
(8, 'Vendor', '4', '<i class=''icon-edit''></i>', 'ACTIVE', 3, 3, '2015-10-19 16:59:20', '2015-10-19 16:59:53'),
(9, 'Product', '5', '<i class=''icon-edit''></i>', 'ACTIVE', 3, 0, '2015-10-19 17:00:14', '2015-10-19 17:00:14'),
(12, 'Setting', '8', '<i class=''icon-edit''></i>', 'ACTIVE', 3, 0, '2015-10-19 17:01:45', '2015-10-19 17:01:45'),
(14, 'Manage Order', '10', '<i class=''icon-edit''></i>', 'ACTIVE', 3, 3, '2015-11-11 09:19:33', '2017-07-30 11:26:55');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE IF NOT EXISTS `product_category` (
`cat_id` int(11) NOT NULL,
  `cat_name` varchar(200) NOT NULL,
  `cat_desc` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`cat_id`, `cat_name`, `cat_desc`, `status`, `c_id`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(1, 'Automobile', 'Automobile products', 'ACTIVE', 0, 3, 3, '2015-10-15 13:04:17', '2017-07-30 12:54:03'),
(4, 'Electronics', 'Electronics products', 'ACTIVE', 0, 3, 3, '2015-10-21 13:53:50', '2015-11-17 15:12:58');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE IF NOT EXISTS `product_master` (
`prod_id` int(11) NOT NULL,
  `prod_categoty` int(11) DEFAULT NULL,
  `prod_name` varchar(255) NOT NULL,
  `prod_display_name` varchar(255) NOT NULL,
  `prod_code` varchar(200) NOT NULL,
  `prod_measure_unit` varchar(500) NOT NULL,
  `prod_price_per_unit` varchar(500) NOT NULL,
  `prod_desc` text NOT NULL,
  `c_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`prod_id`, `prod_categoty`, `prod_name`, `prod_display_name`, `prod_code`, `prod_measure_unit`, `prod_price_per_unit`, `prod_desc`, `c_id`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(5, 4, 'Bearing', 'Bearing', 'Bearing', 'qty', '1500', 'Bearing', 0, 'ACTIVE', 3, 3, '2015-10-12 15:43:40', '2017-08-05 12:20:16'),
(6, 1, 'Gearbox', 'Gearbox', 'Gearbox', 'qty', '2500', 'Gearbox', 0, 'ACTIVE', 3, 3, '2015-10-15 13:25:11', '2017-08-05 12:20:06'),
(8, 1, 'pully', 'pully', 'pully', 'qty', '150', 'test', 0, 'ACTIVE', 3, 3, '2016-03-08 14:49:48', '2017-08-09 18:52:51');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
`setting_id` int(11) NOT NULL,
  `var_key` varchar(100) CHARACTER SET latin1 NOT NULL,
  `var_value` varchar(255) CHARACTER SET latin1 NOT NULL,
  `description` varchar(500) CHARACTER SET latin1 NOT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `var_key`, `var_value`, `description`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(1, 'FYI_FROM_EMAIL', 'no-reply@otsinv.com', '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'FYI_WEB_URL', 'localhost:81/oms/', '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'FYI_EMAIL_IMAGE_PATH', 'http://www.findyourinternship.com/public/images/', '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'FYI_REFER_URL', 'http://www.findyourinternship.com/', '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'PROFILE_IMAGE_PATH', './images/profiles/', 'Profile Images Path', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'PAGING_RECORD_COUNT', '10', 'Pagination record count', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'EMP_IMAGE_PATH', './upload/user/images', 'user profile image path', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'test', 'test', 'test', 3, 0, '2015-10-21 15:10:37', '2015-10-21 15:10:37');

-- --------------------------------------------------------

--
-- Table structure for table `status_master`
--

CREATE TABLE IF NOT EXISTS `status_master` (
`status_id` int(11) NOT NULL,
  `status_name` varchar(200) NOT NULL,
  `status_code` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL,
  `seq` int(11) DEFAULT NULL,
  `release_inventory` int(1) DEFAULT NULL,
  `insertby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `insertdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `status_master`
--

INSERT INTO `status_master` (`status_id`, `status_name`, `status_code`, `status`, `seq`, `release_inventory`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(6, 'Assembly', '', 'ACTIVE', 2, 0, 3, 3, '2015-10-08 19:22:50', '2016-01-18 10:32:01'),
(7, 'Check inventory', '', 'ACTIVE', 1, 0, 3, 3, '2015-10-08 19:23:23', '2017-08-05 11:48:49'),
(8, 'QA', '', 'ACTIVE', 4, 0, 3, 3, '2016-01-08 17:13:50', '2016-01-18 10:32:16'),
(9, 'Paint', '', 'ACTIVE', 3, 0, 3, 3, '2016-01-08 17:14:00', '2016-01-18 10:32:11'),
(10, 'Dispatch', '', 'ACTIVE', 5, 1, 3, 0, '2016-01-08 17:14:12', '2016-01-08 17:14:12');

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE IF NOT EXISTS `user_master` (
`user_id` int(11) NOT NULL,
  `user_type` int(11) DEFAULT NULL,
  `user_full_name` varchar(255) DEFAULT NULL,
  `user_name` varchar(200) DEFAULT NULL,
  `user_email` varchar(200) DEFAULT NULL,
  `user_phone` varchar(30) DEFAULT NULL,
  `user_password` text,
  `company_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `user_image` text,
  `status` varchar(25) DEFAULT NULL,
  `c_id` int(11) NOT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`user_id`, `user_type`, `user_full_name`, `user_name`, `user_email`, `user_phone`, `user_password`, `company_id`, `status_id`, `user_image`, `status`, `c_id`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(4, 3, 'snehal1', 'snehal1', 'snehal1@gmail.com', '8866771642', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, NULL, 'ACTIVE', 0, 1, 3, '2015-10-07 18:44:06', '2017-07-30 12:17:47'),
(3, 1, 'nikunj', 'nikunj', 'nikunjpatel190@gmail.com', '8866771641', '202cb962ac59075b964b07152d234b70', 3, 6, NULL, 'ACTIVE', 0, 1, 3, '2015-10-07 18:30:59', '2017-07-30 07:30:18'),
(7, 6, 'bhavik savaliya', 'bhavik', 'aksharlace1964@gmail.com', '8733013333', '202cb962ac59075b964b07152d234b70', NULL, NULL, NULL, 'ACTIVE', 0, 3, 3, '2017-08-05 11:47:24', '2017-08-29 20:57:14');

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE IF NOT EXISTS `user_types` (
`u_typ_id` int(11) NOT NULL,
  `u_typ_name` varchar(25) DEFAULT NULL,
  `u_typ_code` varchar(25) DEFAULT NULL,
  `u_typ_desc` text,
  `status` varchar(25) DEFAULT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`u_typ_id`, `u_typ_name`, `u_typ_code`, `u_typ_desc`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(1, 'admin', 'admin', 'admin user', 'ACTIVE', NULL, 3, NULL, '2018-11-04 08:11:43'),
(6, 'General', 'General', 'General user', 'ACTIVE', 3, 3, '2017-08-05 11:46:46', '2017-08-05 11:46:50');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_master`
--

CREATE TABLE IF NOT EXISTS `vendor_master` (
`vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `vendor_comp_name` varchar(100) NOT NULL,
  `vendor_phone` varchar(50) NOT NULL,
  `vendor_email` varchar(150) NOT NULL,
  `vendor_address` text NOT NULL,
  `vendor_city` varchar(100) NOT NULL,
  `vendor_state` varchar(100) NOT NULL,
  `vendor_country` varchar(100) NOT NULL,
  `vendor_postal_code` varchar(20) NOT NULL,
  `c_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `insertby` int(11) DEFAULT NULL,
  `updateby` int(11) DEFAULT NULL,
  `insertdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `vendor_master`
--

INSERT INTO `vendor_master` (`vendor_id`, `vendor_name`, `vendor_comp_name`, `vendor_phone`, `vendor_email`, `vendor_address`, `vendor_city`, `vendor_state`, `vendor_country`, `vendor_postal_code`, `c_id`, `status`, `insertby`, `updateby`, `insertdate`, `updatedate`) VALUES
(1, 'bharatbhai ambabhai ramani', 'bhavani brocket', '8511399754', 'bhavanibrocket1@gmail.com', 'E-145, matru shakti soc. Puna gam', 'surat', 'gujarat', 'india', '360004', 0, 'ACTIVE', 3, 3, '2015-10-26 13:52:17', '2017-08-27 08:25:52'),
(2, 'popatbhai ambabhai ramani', 'shiv traders', '8767568798', 'popat.xyz.test@gmail.com', 'b-8, krishna bhunglows', 'rajkot', 'gujarat', 'india', '360004', 0, 'ACTIVE', 3, NULL, '2017-08-27 08:29:23', '2017-08-27 08:29:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `combo_master`
--
ALTER TABLE `combo_master`
 ADD PRIMARY KEY (`combo_id`);

--
-- Indexes for table `customer_master`
--
ALTER TABLE `customer_master`
 ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
 ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `item_color_master`
--
ALTER TABLE `item_color_master`
 ADD PRIMARY KEY (`item_color_id`);

--
-- Indexes for table `item_thickness_master`
--
ALTER TABLE `item_thickness_master`
 ADD PRIMARY KEY (`item_thk_id`);

--
-- Indexes for table `map_usertype_module`
--
ALTER TABLE `map_usertype_module`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `map_user_status`
--
ALTER TABLE `map_user_status`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `module_master`
--
ALTER TABLE `module_master`
 ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `order_master`
--
ALTER TABLE `order_master`
 ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_product_detail`
--
ALTER TABLE `order_product_detail`
 ADD PRIMARY KEY (`opd_id`);

--
-- Indexes for table `order_product_status`
--
ALTER TABLE `order_product_status`
 ADD PRIMARY KEY (`ops_id`);

--
-- Indexes for table `panel_master`
--
ALTER TABLE `panel_master`
 ADD PRIMARY KEY (`panel_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
 ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
 ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `status_master`
--
ALTER TABLE `status_master`
 ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
 ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
 ADD PRIMARY KEY (`u_typ_id`);

--
-- Indexes for table `vendor_master`
--
ALTER TABLE `vendor_master`
 ADD PRIMARY KEY (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `combo_master`
--
ALTER TABLE `combo_master`
MODIFY `combo_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `customer_master`
--
ALTER TABLE `customer_master`
MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
MODIFY `invoice_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `item_color_master`
--
ALTER TABLE `item_color_master`
MODIFY `item_color_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `item_thickness_master`
--
ALTER TABLE `item_thickness_master`
MODIFY `item_thk_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `map_usertype_module`
--
ALTER TABLE `map_usertype_module`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `map_user_status`
--
ALTER TABLE `map_user_status`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `module_master`
--
ALTER TABLE `module_master`
MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `order_master`
--
ALTER TABLE `order_master`
MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `order_product_detail`
--
ALTER TABLE `order_product_detail`
MODIFY `opd_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `order_product_status`
--
ALTER TABLE `order_product_status`
MODIFY `ops_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `panel_master`
--
ALTER TABLE `panel_master`
MODIFY `panel_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `status_master`
--
ALTER TABLE `status_master`
MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user_master`
--
ALTER TABLE `user_master`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user_types`
--
ALTER TABLE `user_types`
MODIFY `u_typ_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vendor_master`
--
ALTER TABLE `vendor_master`
MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
